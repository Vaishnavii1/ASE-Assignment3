# ASE-Assignment-3

This main objective of this assignment  is to learning how to code! and commit it into githib repository. We'll use a helpful video tutorial that breaks down the steps involved in building a specific program. This guide will provide you with all the information you need to access the project files and walk you through the coding process step-by-step.

##  Learning Objectives
Here's what you'll accomplish in this project:

- Grasp the coding concepts presented in the video tutorial.
- Code the project yourself, following the instructor's step-by-step guidance.
- Securely store your completed project by uploading it to your GitHub repository.

## Step-by-Step Guide

- Watch the Tutorial: Head over to YouTube and watch the video tutorial (https://www.youtube.com/watch?v=SqcY0GlETPk&t=1031s)



- Test and Debug: After coding each section, test it thoroughly to ensure it works as expected. Troubleshoot any issues you encounter until your code matches the video's results.

- Commit to GitHub: Once you've completed the project, upload your code to your GitHub repository to keep track of your progress.

